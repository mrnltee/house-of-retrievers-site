The House of Retrievers' Society, Inc. - logo files

svg/  vector artwork, any size
png/  transparent PNGs for slides and documents

Use the "on light" files on white or pale backgrounds and the "on dark" files on black.
Logo colours: Retriever Gold #AD8330, Ink #0D0D0D, Paper #FFFFFF.
Keep clear space equal to the height of the H in HOUSE on every side.
Minimum width: horizontal 180 px / 45 mm, stacked 120 px / 30 mm.
Do not recolour, rotate, stretch, crop, add effects, or retype the wordmark.

Full guidelines: https://media.houseofretrieversph.org/#brand-assets
Questions: houseofretrieversph@gmail.com
